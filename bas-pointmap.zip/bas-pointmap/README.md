# bas-pointmap

**Turns messy, multi-vendor BAS point names into Project Haystack tags and Brick classes, scores its own confidence, and refuses to guess.**

Onboarding a building to an analytics or AI-driven HVAC platform starts with the same job every time: take a point list written by whoever programmed the controllers, figure out what each point actually is, and map it to a standard. The same discharge air temperature arrives as `#pine_paper/rtu_1/da_temp` from one site, `RTU1-DAT` from another and `Rtu #1 Disch Air Tmp` from a third. Done by hand, that work is slow. Done by naive string matching, it is dangerous: a mislabeled point feeds wrong data straight into a control decision.

`pointmap` maps what the evidence proves, shows its reasoning for every point, and sends everything else to a human review queue.

---

## In 30 seconds

| Vendor point (as exported) | Metadata | pointmap result | Status |
|---|---|---|---|
| `OFFICE-A:NAE-01/FC-1.AHU-1.SA-SP` | AI, inH₂O | `AHU-01.DA-P`, supply static pressure **sensor** | auto 1.00 |
| `OFFICE-A:NAE-01/FC-2.VMA-203.ZN-SP` | AV, °F | `VAV-203.ZN-T-SP`, zone temperature **setpoint** | auto 0.80 |
| `OFFICE-A:NAE-01/FC-1.AHU-1.SA-SP-SP` | AV, inH₂O | `AHU-01.DA-P-SP`, static pressure **setpoint** | auto 0.95 |
| `/Drivers/BacnetNetwork/RTU_4/points/HtgStg2` | BO | `RTU-04.HTG-STG2-C`, heating stage 2 command | auto 0.80 |
| `vav2-03_ZN_TEMP_DegF` | AI | `VAV-2-03.ZN-T`, unit read from the name | auto 1.00 |
| `EF-2 S/S` | BO | `EF-02.EF-C`, exhaust fan start/stop | auto 0.80 |
| `#pine_paper/rtu_1/sf_status` | **AI, amps** | **Refused.** A "status" that reads amps is a current transducer, not proof of flow. Confirm the wiring first. | review |
| `SPARE_AI_3` | AI | **Refused.** Spare I/O | review |

The first three rows are the core idea: `SP` means *setpoint* in one name and *static pressure* in another, and only the metadata can tell them apart. The seventh row is the commissioning idea: the tool doesn't just decline to map that point, it also marks RTU-01 **BLOCKED** in the readiness report, because a platform that can't prove the supply fan runs shouldn't be controlling the unit.

**Results:** see [Benchmark results](#benchmark-results).

---

## How it works (3 minutes)

```mermaid
flowchart LR
    A["Vendor export (CSV)<br/>ALC · Metasys · Niagara · hand-typed"] --> B["ingest<br/>columns · object types · units"]
    B --> C["tokens<br/>vendor path · equipment · tokens"]
    C --> D["classify<br/>hypotheses · evidence · confidence"]
    D --> E["qa<br/>readiness · duplicates · anomalies"]
    E --> F["tagged_points.csv"]
    E --> G["haystack.json"]
    E --> H["brick.ttl"]
    E --> I["qa_report.md"]
    E --> J["review_queue.csv"]
    R[("rules/*.yaml")] -.-> B & C & D & E
```

**Evidence, not string matching.** Every point is judged on four independent sources: the name, the BACnet object type, the engineering units and the description. A name that fully defines a point and is confirmed by its object type and units scores 1.00. A name that needed the metadata to fill a gap starts lower. Metadata that contradicts the name costs heavily: units that disagree with the quantity are the strongest warning sign in a point list.

**Three outcomes, never a silent guess.**

| Status | Confidence | Meaning | Goes into the Haystack / Brick model? |
|---|---|---|---|
| `auto` | ≥ 0.80 | Evidence agrees. Safe to load. | Yes |
| `flagged` | 0.50 to 0.79 | Accepted, but a person should spot-check it. | Yes, marked for review in the CSV |
| `review` | < 0.50, or unattachable | Not trusted. A person decides. | **No** |

Points the tool refuses outright go to `review_queue.csv` with a plain-language reason: spare and test points, PID tuning gains, alarms, points that can't be attached to any equipment, and points whose metadata contradicts their name.

**Deployment readiness, not just tagging.** Each equipment type has a template of points an optimisation platform needs (`rules/equipment_templates.yaml`). The QA report marks every unit **READY** or **BLOCKED** and lists what is missing, so the conversation with the site is "RTU-04 has no fan status point" rather than "some points didn't map".

**What you get per site**

| File | For |
|---|---|
| `qa_report.md` | The controls lead: readiness per unit, anomalies, review queue summary. Read this first. |
| `review_queue.csv` | The person resolving exceptions: best guess, confidence, reason. |
| `tagged_points.csv` | Everyone: every point with canonical name, tags, class, confidence, flags and the full evidence trail. |
| `haystack.json` | Loading into a Haystack-based platform (site → equip → point, Hayson grid). |
| `brick.ttl` | Loading into a Brick / RDF-based platform. |

Operating procedure for a real onboarding: [docs/RUNBOOK.md](docs/RUNBOOK.md).

---

## Engineering detail

### Quick start

```bash
git clone https://github.com/<your-github>/bas-pointmap.git && cd bas-pointmap
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

pointmap map data/raw/office_a_metasys.csv --site OFFICE-A --out output/office_a
pointmap evaluate output/office_a/tagged_points.csv data/ground_truth/office_a.csv
pytest
```

Python 3.11+. Runtime dependencies: pandas, PyYAML. Development: pytest, rdflib (used by the tests to prove `brick.ttl` parses). No machine learning, no network calls, no external services.

### Repository layout

```
pointmap/
  ingest.py       stage 1  read CSV; normalize headers, object types, units, encodings
  tokens.py       stage 2  split vendor paths; find equipment; tokenize the point name
  classify.py     stage 3  hypotheses → candidate roles → evidence-weighted score
  qa.py           stage 4  readiness per equipment, duplicates, anomalies
  export/         stage 5  tables.py · haystack.py · brick.py · report.py
  pipeline.py     wires the stages together
  evaluate.py     scores a run against a hand-labelled answer key
  cli.py          `pointmap map` and `pointmap evaluate`
rules/
  abbreviations.yaml         token dictionary, ambiguous tokens, units, BACnet types
  point_roles.yaml           the mapping standard: 33 roles with Haystack tags and Brick classes
  equipment_templates.yaml   9 equipment types, aliases, required/recommended points
data/raw/                    mock vendor exports, 4 sites
data/ground_truth/           hand-labelled answer keys
examples/output/             committed outputs, so results are reviewable without running anything
docs/RUNBOOK.md              operating procedure
tests/
```

### Walking one point through the pipeline

`OFFICE-A:NAE-01/FC-2.VMA-203.ZN-SP`, object type AV, units `deg F`:

1. **ingest** normalizes `deg F` to `°F` (family: temp) and confirms `AV` is a known object type.
2. **tokens** splits the Metasys reference on `:` `/` `.`, searches segments right-to-left for equipment and finds `VMA-203`, a Metasys VAV alias, giving `VAV-203`. The point tokens are `ZN`, `SP`.
3. **classify** reads `ZN` as position=zone. `SP` is declared ambiguous, so two hypotheses are tested: *setpoint* and *static pressure*. Under *setpoint*, role `ZN-T-SP` needs a quantity the name doesn't give; the units supply temp, so the name "needed metadata" and starts at 0.45. Under *static pressure*, no role describes a zone pressure sensor, so that hypothesis produces nothing.
4. **Score:** 0.45 base, −0.05 for the ambiguous token, +0.20 AV agrees, +0.20 °F agrees = **0.80 → auto**.

The `evidence` column records exactly that, in that order:

```
equipment: 'VMA-203' -> vav VAV-203 | tokens: ZN=position=zone · SP=?(function=sp or quantity=pressure)
| quantity=temp inferred from units °F | score: name needed metadata to be complete +0.45,
ambiguous token resolved (SP→function=sp) -0.05, object type AV agrees +0.20, units °F agree +0.20 = 0.80
```

### Design decisions

**Rules in YAML, logic in Python.** All BAS domain knowledge (abbreviations, point roles, equipment templates) lives in three YAML files. Teaching the tool a new vendor convention is a one-line rule change reviewed like code, not a code change. Rule files are validated at load time: an unknown dimension, a template entry that matches no role, or a duplicate alias fails before any point is processed.

**Deterministic rules instead of a model.** Point mapping feeds control decisions, so every result must be explainable to the engineer who signs off the site and reproducible on re-run. The same input and rules produce byte-identical output (no timestamps, stable ordering), so a rules change shows up in `git diff` as exactly the points it affected.

**Ambiguity is resolved by evidence, not by default.** `SP`, `SPT`, `OUT` and `RUN` fork into competing hypotheses, and the object type and units pick the winner. If a *different* role scores within 0.10 of the winner, the point is marked ambiguous and penalised instead of picked. When one token appears twice (`SA-SP-SP`), readings where an ambiguous token adds nothing new are discarded, so the two `SP`s resolve to one static pressure and one setpoint.

**Conventions versus inference.** Some gaps are filled by how people write names: a measured quantity with no SP/CMD word is a sensor; a heating stage with no function word is its command. Those keep full confidence. Gaps filled from metadata (function from the object type, quantity from the units) lower the base score, because the name alone didn't carry the meaning.

**Equipment context, never invention.** A bare `fan` on an RTU is the supply fan, and `S/S` on an exhaust fan starts that fan. Context only fills gaps; it never overwrites what the name says. Equipment ids are normalized but not invented: `VMA-203` becomes `VAV-203`, not `VAV-2-03`, because nothing in the name says which floor it is on.

**Refuse rather than orphan.** A point that can't be attached to equipment goes to review even if its role is certain, because it can't be modelled or controlled. Only roles declared `site_level` (outside air temperature and humidity) may live on the site itself.

**Fuzzy matching can only lower confidence.** One typo-recovery attempt per unknown token (stdlib `difflib`, similarity ≥ 0.82, tokens of 4+ characters). A fuzzy read is recorded in the flags and costs 0.10, so a typo can be mapped but never auto-accepted on a guess.

### Scoring model

Scores are the sum of the terms below, clipped to 0–1. The weights live together at the top of `classify.py`.

| Term | Weight |
|---|---:|
| Name defines the role (with conventions and equipment context) | +0.60 |
| Name needed metadata to be complete (instead of the above) | +0.45 |
| Ambiguous token resolved by evidence | −0.05 |
| Object type agrees / contradicts | +0.20 / −0.25 |
| Units agree / contradict | +0.20 / −0.30 |
| Description agrees / contradicts | +0.05 / −0.10 |
| Name carries a meaning the role doesn't use (each) | −0.10 |
| Unknown token (each, capped at −0.30) | −0.10 |
| Token recovered by fuzzy match (each) | −0.10 |
| Role unusual on this equipment type | −0.15 |
| No equipment found (non-site-level roles) | −0.20 |
| A different role scored within 0.10 | −0.15 |

The weights are engineering judgement, not fitted parameters. The benchmark exists to show whether they hold up.

### Extending the rules

A new vendor abbreviation goes in `rules/abbreviations.yaml`:

```yaml
tokens:
  DCHG: {position: discharge}
```

A new kind of point goes in `rules/point_roles.yaml`, with its requirements, the metadata that agrees with it, and its Haystack tags and Brick class. A new equipment type, or a change to what "ready" means for one, goes in `rules/equipment_templates.yaml`. Re-run the benchmark after any rule change: a rule that fixes one site and breaks another shows up immediately in the evaluation.

### Benchmark results

<!-- Generated by `pointmap evaluate --markdown` over all four sites. Do not edit by hand. -->

_Pending: populated from the benchmark run._

The benchmark is four synthetic sites (about 250 points), each modelled on a real vendor's naming conventions, with deliberate traps: ambiguous abbreviations, status points wired as analog inputs, units that contradict names, duplicates, typos, site-level points and junk. Every point has a hand-labelled answer, including the ones the tool **should** refuse. The metrics that matter:

| Metric | Why it matters |
|---|---|
| Auto-accepted precision | When the tool says "safe to load", how often it is right |
| Silent errors | Auto-accepted **and** wrong: the number that must be as close to zero as possible |
| Correct refusals | Of the points that should be refused, how many were |
| Coverage | Share of points accepted with no human involvement |

### Standards

Tag and class names were checked against the official sources, not written from memory: Project Haystack 4 defs ([haystack-defs](https://github.com/Project-Haystack/haystack-defs), commit `d042781`) and the Brick Schema 1.3.0 release ontology. Where Brick 1.3 has no specific class, the nearest verified parent is used and noted in the rule file (zone CO₂ uses `CO2_Sensor`; unit and vestibule heaters use `Space_Heater`). The Haystack export uses one custom tag, `pointmapSource`, to carry the original vendor name for traceability.

### Limitations

These are deliberate scope limits for v0.1, listed so nobody has to discover them.

The rule set covers 33 point roles on 9 equipment types, weighted toward packaged rooftop units, AHUs, VAV boxes and small heating equipment. Anything outside it goes to review until a rule is added, which is the intended behaviour. Equipment must appear somewhere in the point name or vendor path; mapping points to equipment through a separate device list is not yet supported. Points attach to their parent equipment; sub-equipment (for example a supply fan modelled as its own equipment inside an AHU) is not modelled. Units are checked for consistency but not converted. The Haystack export carries no connector, history or timezone tags. The benchmark sites are synthetic: they measure the rules against known conventions and designed traps, not field accuracy on an unseen building.

### License

MIT. See [LICENSE](LICENSE).
